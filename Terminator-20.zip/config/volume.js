module.exports = {
    'earrape': '1000',
    'normal': '100',
};